from django.apps import AppConfig


class FlowConfig(AppConfig):
    name = 'flow'
