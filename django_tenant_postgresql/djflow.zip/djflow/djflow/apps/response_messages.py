from django.utils.translation import ugettext as _

SAVE_SUCCESSFULL = _("Creado correctamente")
UPDATE_SUCCESSFULL = _("Actualizado correctamente")
DELETE_SUCCESSFULL = _("Eliminado correctamente")

SAVE_ERROR = _("Creado correctamente")
UPDATE_ERROR = _("Actualizado correctamente")
DELETE_ERROR = _("Eliminado correctamente")
