DATABASE_ROUTERS = {
	'tenant_schemas.routers.TenantSyncRouter'
}